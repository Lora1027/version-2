# Inkhale Business Platform v2
See supabase/schema.sql and .env.local.example.
